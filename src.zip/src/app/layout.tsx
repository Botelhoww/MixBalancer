// layout.tsx
import { Suspense } from 'react';
import '../styles/globals.css';
import { AuthProvider } from '@/context/AuthContext';
import NavBarWrapper from '../components/NavBarWrapper';

export const metadata = {
  title: 'MixBalancer',
  description: 'Manage teams, players, and matches efficiently',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <Suspense fallback={null}>
            <NavBarWrapper />
          </Suspense>
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}