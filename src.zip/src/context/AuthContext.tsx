'use client';

import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { authService } from '@/services/authService';

interface User {
  id: string;
  name: string;
  email: string;
}

interface AuthContextProps {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;  // Add this
  login: (token: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);  // Add this

 // src/context/AuthContext.tsx
const login = async (newToken: string) => {
  try {
    setToken(newToken);
    localStorage.setItem('token', newToken);
    
    // Get user data from getCurrentUser
    const userData = await authService.getCurrentUser();
    if (userData.success) {
      setUser(userData.user);
      setIsAuthenticated(true);
    } else {
      throw new Error(userData.message);
    }
  } catch (error) {
    console.error('Error setting up user session:', error);
    logout();
    throw error; // Rethrow to handle in the login page
  }
};

  const logout = () => {
    setToken(null);
    setUser(null);
    setIsAuthenticated(false);  // Set this when logging out
    localStorage.removeItem('token');
  };

  // Check authentication status on mount
  useEffect(() => {
    const checkAuth = async () => {
      const storedToken = localStorage.getItem('token');
      if (storedToken) {
        await login(storedToken);
      }
    };
    
    checkAuth();
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};