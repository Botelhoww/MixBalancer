// src/services/authService.ts
import api from './api';

interface LoginResponse {
  token: string;
  user: {
    id: string;
    name: string;
    email: string;
  };
}

export const authService = {
  login: async ({ email, password }: { email: string; password: string }) => {
    try {
      const response = await api.post<LoginResponse>('/auth/login', { email, password });
      return {
        success: true,
        token: response.data.token,
        user: response.data.user // Make sure your API returns the user with the login response
      };
    } catch (error: any) {
      return {
        success: false,
        message: error.response?.data?.message || 'Falha no login'
      };
    }
  },

  getCurrentUser: async () => {
    try {
      const response = await api.get('/auth/me');
      return {
        success: true,
        user: response.data.user
      };
    } catch (error: any) {
      return {
        success: false,
        message: error.response?.data?.message || 'Não foi possível carregar as informações do usuário'
      };
    }
  }
};