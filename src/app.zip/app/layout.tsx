import '../styles/globals.css';

export const metadata = {
  title: 'MixBalancer',
  description: 'Manage teams, players, and matches efficiently',
};

const RootLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <html lang="en">
      <body>
        <div>
          <nav>
            <ul>
              <li>
                <a href="/players">Players</a>
              </li>
              <li>
                <a href="/teams">Teams</a>
              </li>
              <li>
                <a href="/matches">Matches</a>
              </li>
              <li>
                <a href="/auth/login">Login</a>
              </li>
              <li>
                <a href="/auth/register">Register</a>
              </li>
            </ul>
          </nav>
          <main>{children}</main>
        </div>
      </body>
    </html>
  );
};

export default RootLayout;
