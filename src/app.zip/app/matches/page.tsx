import React from 'react';
import MatchList from './MatchList';
import MatchForm from './MatchForm';

const MatchesPage: React.FC = () => {
  return (
    <div>
      <h1>Matches</h1>
      <MatchForm />
      <MatchList />
    </div>
  );
};

export default MatchesPage;