'use client';
import React, { useState } from 'react';
import { playerService } from '@/services/playerService';

const PlayerForm: React.FC = () => {
  const [nickname, setNickname] = useState('');
  const [skillLevel, setSkillLevel] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await playerService.createPlayer({ nickname, skillLevel });
    if (result.success) {
      alert('Player created successfully');
      setNickname('');
      setSkillLevel(0);
    } else {
      alert('Error: ' + result.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Nickname</label>
        <input
          type="text"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          required
        />
      </div>
      <div>
        <label>Skill Level</label>
        <input
          type="number"
          value={skillLevel}
          onChange={(e) => setSkillLevel(Number(e.target.value))}
          required
        />
      </div>
      <button type="submit">Create Player</button>
    </form>
  );
};

export default PlayerForm;