'use client';
import React, { useEffect, useState } from 'react';
import { playerService } from '@/services/playerService';

const PlayerList: React.FC = () => {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    const fetchPlayers = async () => {
      const result = await playerService.getPlayers();
      if (result.success) {
        setPlayers(result.data);
      }
    };
    fetchPlayers();
  }, []);

  return (
    <div>
      <h2>Player List</h2>
      <ul>
        {players.map((player: any) => (
          <li key={player.id}>
            {player.nickname} - Skill Level: {player.skillLevel}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PlayerList;