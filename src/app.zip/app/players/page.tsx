import React from 'react';
import PlayerList from './PlayerList';
import PlayerForm from './PlayerForm';

const PlayersPage: React.FC = () => {
  return (
    <div>
      <h1>Players</h1>
      <PlayerForm />
      <PlayerList />
    </div>
  );
};

export default PlayersPage;