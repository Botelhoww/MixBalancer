'use client';
import React, { useState } from 'react';
import { teamService } from '@/services/teamService';

const TeamForm: React.FC = () => {
  const [name, setName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await teamService.createTeam({ name });
    if (result.success) {
      alert('Team created successfully');
      setName('');
    } else {
      alert('Error: ' + result.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Team Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>
      <button type="submit">Create Team</button>
    </form>
  );
};

export default TeamForm;