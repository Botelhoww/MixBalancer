'use client';
import React, { useEffect, useState } from 'react';
import { teamService } from '@/services/teamService';

const TeamList: React.FC = () => {
  const [teams, setTeams] = useState([]);

  useEffect(() => {
    const fetchTeams = async () => {
      const result = await teamService.getTeams();
      if (result.success) {
        setTeams(result.data);
      }
    };
    fetchTeams();
  }, []);

  return (
    <div>
      <h2>Team List</h2>
      <ul>
        {teams.map((team: any) => (
          <li key={team.id}>
            {team.name} - Avg Skill Level: {team.averageSkillLevel}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TeamList;