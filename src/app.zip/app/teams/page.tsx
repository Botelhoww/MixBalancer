import React from 'react';
import TeamList from './TeamList';
import TeamForm from './TeamForm';

const TeamsPage: React.FC = () => {
  return (
    <div>
      <h1>Teams</h1>
      <TeamForm />
      <TeamList />
    </div>
  );
};

export default TeamsPage;